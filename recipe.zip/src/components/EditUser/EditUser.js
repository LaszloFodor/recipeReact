import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import fetch from 'isomorphic-fetch';

class EditUser extends Component {

  static propTypes = {
    onError: PropTypes.func,
    history: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  };

  static defaultProps = {
    onError: null,
  };

  constructor() {
    super();

    this.user = {
      user: null,
    };

  }

  componentDidMount() {
    const headers = {};
    const accessToken = localStorage.getItem('accessToken');

    if (accessToken) {
      headers['Authorization'] = 'Bearer ' + accessToken;
    }

    fetch(`/api/user/${this.props.userId}`, {
      credentials: 'same-origin',
      method: 'GET',
      headers,
    })
      .then((response) => {
        if (response.status < 200 || response.status >= 300) {
          throw new Error('Error in server response!');
        }
        return response.json();
      })
      .catch((error) => {
        if (this.props.onError) {
          this.props.onError(error);
        }
        // no data or error happened
      })
      .then((user) => {
        this.setState({ user: user || null });
      });
  }

  onSubmitForm = (event) => {
    const { user } = this.props.user;
    event.preventDefault();

    const headers = {};
    const accessToken = localStorage.getItem('accessToken');
    if (accessToken) {
      headers['Authorization'] = 'Bearer ' + accessToken;
    }

    fetch(`/api/user/${recipe.id}`, {
      credentials: 'same-origin',
      method: 'PUT',
      body: JSON.stringify(user),
      headers,
    })
      .then((response) => {
        if (response.status < 200 || response.status >= 300) {
          throw new Error('Error in server response!');
        }
        return response.json();
      })
      .catch((error) => {
        if (this.props.onError) {
          this.props.onError(error);
        }
        // no data or error happened
      })
      .then((user) => {
        this.setState({ user: user || null });
      });
  };

  onInputChange = (event) => {
      // TODO
  };

  onBackClick = () => this.props.history.goBack();

  render() {

    const { user } = this.props.user;

    if (!user) {
      return <div className="edit-user">Loading or no user found...</div>
    }

    return (
      <form className="edit-user" onSubmit={this.onSubmitForm}>
        <div>
          <div className="user-name">
            <label htmlFor="name">Username:</label>
            <input type="text" id="name" value={user.username} onChange={this.onInputChange} />
          </div>
          <div className="user-password">
            <label htmlFor="name">Password:</label>
            <input type="password" id="password" value={user.password} onChange={this.onInputChange} />
          </div>
          <div className="user-firstname">
            <label htmlFor="firstname">First name:</label>
            <input type="text" id="firstname" value={user.firstName} onChange={this.onInputChange} />
          </div>
          <div className="user-lastname">
            <label htmlFor="lastname">Last name:</label>
            <input type="text" id="lastname" value={user.lastName} onChange={this.onInputChange} />
          </div>
          <div className="user-email">
            <label htmlFor="email">Email:</label>
            <input type="text" id="email" value={user.email} onChange={this.onInputChange} />
          </div>
          <ul className="roles">
            <label htmlFor="categories">Roles:</label>
            {(user.authorities || []).map(role =>
              <li key={role.id}>
                <input type="text" id="authorities.name" data-id={role.id} value={role.name} onChange={this.onInputChange} />
              </li>
            )}
          </ul>
        </div>
        <div className="actions">
          <button type="submit">Edit</button>
          <button type="button" onClick={this.onBackClick}>Close</button>
        </div>
      </form>
    );



  }

}